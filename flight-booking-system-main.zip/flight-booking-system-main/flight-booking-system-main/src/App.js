import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import AuthPage from './Pages/AuthPage';
import FlightSearchPage from './Pages/FlightSearchPage';
import AdminPage from './Pages/AdminPage';
import FlightResultsPage from './Pages/FlightResultsPage';
import ProfilePage from './Pages/ProfilePage';
import PaymentGateway from './Pages/PaymentGateway';
import BookingDetailsPage from './Pages/BookingDetailsPage';
import CovidGuidelines from './Pages/CovidGuidelines';
import TermsAndConditions from './Pages/TermsAndConditions';
import Checkin from './Pages/Checkin';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
  };

  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Login Route */}
          <Route
            path="/"
            element={
              isLoggedIn ? 
                (isAdmin ? <Navigate to="/admin" replace /> : <Navigate to="/booking" replace />) : 
                <AuthPage setIsLoggedIn={setIsLoggedIn} setIsAdmin={setIsAdmin} />
            }
          />

          {/* User Booking Route */}
          <Route
            path="/booking"
            element={
              isLoggedIn && !isAdmin ? 
                <FlightSearchPage onLogout={handleLogout} /> : 
                <Navigate to="/" replace />
            }
          />

          {/* Admin Route */}
          <Route
            path="/admin"
            element={
              isLoggedIn && isAdmin ? 
                <AdminPage onLogout={handleLogout} /> : 
                <Navigate to="/" replace />
            }
          />

          {/* Flight Results Route */}
          <Route
            path="/flight-results"
            element={
              isLoggedIn ? 
                <FlightResultsPage onBack={() => window.history.back()} /> : 
                <Navigate to="/" replace />
            }
          />

          {/* Profile Route */}
          <Route
            path="/profile"
            element={
              isLoggedIn ? 
                <ProfilePage /> : 
                <Navigate to="/" replace />
            }
          />

          {/* Payment Gateway Route */}
          <Route
            path="/payment-gateway"
            element={
              isLoggedIn ? <PaymentGateway /> : <Navigate to="/" replace />
            }
          />

          {/* Booking Details Route */}
          <Route
            path="/booking-details"
            element={
              isLoggedIn && !isAdmin ? <BookingDetailsPage /> : <Navigate to="/" replace />
            }
          />

          {/* Covid Guidelines Route */}
          <Route
            path="/covid-guidelines"
            element={<CovidGuidelines />}
          />

          {/* Terms and Conditions Route */}
          <Route
            path="/terms-and-conditions"
            element={<TermsAndConditions />}
          />

          {/* Check-in Route */}
          <Route
            path="/checkin"
            element={<Checkin />}
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;