import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import bgImage from '../Assets/images/flight-booking-hero.jpg';

const BookingDetailsPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { flight } = location.state || {};
  const [numPassengers, setNumPassengers] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (!flight) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-lg text-center">
          <h2 className="text-2xl font-bold mb-4">No flight selected</h2>
          <p>Please select a flight from the search results.</p>
        </div>
      </div>
    );
  }

  // Use seatClass from flight (passed from search/results)
  const seatType = flight.seatClass || "economy";

  // Dummy booking object, you can extend this as needed
  const booking = {
    // Add user/passenger details here if needed
    flightId: flight.flightId,
    // ...other booking details
  };

  const handleProceed = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `http://localhost:8100/bookTickets/${flight.flightId}/${seatType}/${numPassengers}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(booking),
        }
      );
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(errText || "Booking failed");
      }
      const msg = await res.text();
      // Extract price from backend response: "Order created successfully. Please pay amount {price} Booking Successfully"
      const priceMatch = msg.match(/amount ([\d.]+)/);
      const price = priceMatch ? priceMatch[1] : flight.price;
      navigate("/payment-gateway", {
        state: { flight, numPassengers, seatType, price },
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{
        backgroundImage: `linear-gradient(rgba(30,64,175,0.7),rgba(30,64,175,0.7)), url(${bgImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="bg-white rounded-2xl shadow-2xl p-10 w-full max-w-xl">
        <h2 className="text-3xl font-bold text-blue-900 mb-6 text-center">
          Booking Details
        </h2>
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="font-semibold text-gray-700">Flight:</span>
            <span className="font-bold text-blue-700">
              {flight.airline} {flight.flightId}
            </span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="font-semibold text-gray-700">Source:</span>
            <span>{flight.origin || flight.from}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="font-semibold text-gray-700">Destination:</span>
            <span>{flight.destination || flight.to}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="font-semibold text-gray-700">Departure:</span>
            <span>{flight.flightTime || flight.departureTime}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="font-semibold text-gray-700">Price:</span>
            <span className="font-bold text-green-700">
              ₹{String(flight.price).replace("$", "")}
            </span>
          </div>
        </div>
        <div className="mb-6">
          <label className="block font-semibold mb-2 text-gray-700">
            Number of Passengers
          </label>
          <select
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
            value={numPassengers}
            onChange={(e) => setNumPassengers(Number(e.target.value))}
          >
            {[...Array(9)].map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>
        </div>
        {error && (
          <div className="mb-4 text-red-600 text-center font-semibold">{error}</div>
        )}
        <button
          onClick={handleProceed}
          className="w-full py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg text-lg disabled:opacity-60"
          disabled={loading}
        >
          {loading ? "Processing..." : "Proceed to Payment"}
        </button>
      </div>
    </div>
  );
};

export default BookingDetailsPage;
