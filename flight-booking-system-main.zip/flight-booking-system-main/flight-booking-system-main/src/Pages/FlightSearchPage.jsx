import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, Transition } from '@headlessui/react';
import { ChevronDownIcon, UserIcon, LogoutIcon } from '@heroicons/react/outline';
import AirportInput from '../Components/FlightSearch/AirportInput';
import SwapButton from '../Components/FlightSearch/SwapButton';
import DateInput from '../Components/FlightSearch/DateInput';
import PassengerClassSelect from '../Components/FlightSearch/PassengerClassSelect';

// Import images
import heroImage from '../Assets/images/flight-booking-hero.jpg';
import londonImage from '../Assets/images/popular-destinations/london.jpg';
import newYorkImage from '../Assets/images/popular-destinations/new-york.jpg';
import parisImage from '../Assets/images/popular-destinations/paris.jpg';
import tokyoImage from '../Assets/images/popular-destinations/tokyo.jpg';
import dubaiImage from '../Assets/images/popular-destinations/dubai.jpg';
import bgVideo from '../Assets/images/bgvideo.mp4';
import logo from '../Assets/images/logo.jpg';

const FlightSearchPage = ({ onLogout }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    from: '',
    to: '',
    flightDate: '', // changed from 'departure'
    return: '',
    seatClass: 'economy', // changed from 'class'
  });

  const [suggestions, setSuggestions] = useState({
    from: [],
    to: [],
  });

  const [activeField, setActiveField] = useState(null);

  // Store seats by class
  const [seatsByClass, setSeatsByClass] = useState([]);

  // Set default dates on component mount
  useEffect(() => {
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);

    setFormData(prev => ({
      ...prev,
      flightDate: today.toISOString().split('T')[0], // changed from 'departure'
      return: tomorrow.toISOString().split('T')[0]
    }));
  }, []);

  // Fetch seats by class from backend when seatClass changes
  useEffect(() => {
    if (!formData.seatClass) return;
    const fetchSeats = async () => {
      try {
        const res = await fetch(`http://localhost:8082/seats/class/${formData.seatClass}`);
        if (res.ok) {
          const seats = await res.json();
          setSeatsByClass(seats);
        } else {
          setSeatsByClass([]);
        }
      } catch {
        setSeatsByClass([]);
      }
    };
    fetchSeats();
  }, [formData.seatClass]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if (name === 'from' || name === 'to') {
      setActiveField(name);
      if (value.length > 1) {
        // TODO: Replace airports filtering with real data source or API
        const filtered = [];
        setSuggestions(prev => ({ ...prev, [name]: filtered }));
      } else {
        setSuggestions(prev => ({ ...prev, [name]: [] }));
      }
    }
  };

  const handleSuggestionClick = (field, airport) => {
    const displayValue = `${airport.city} (${airport.code})`;
    setFormData(prev => ({ ...prev, [field]: displayValue }));
    setSuggestions(prev => ({ ...prev, [field]: [] }));
    setActiveField(null);
  };

  const handleSwap = () => {
    setFormData(prev => ({
      ...prev,
      from: prev.to,
      to: prev.from,
    }));
  };

  const handleSearch = async (e) => {
    e.preventDefault();

    // Extract values
    const origin = formData.from.split('(')[0].trim();
    const destination = formData.to.split('(')[0].trim();
    const flightDate = formData.flightDate;
    const seatClass = formData.seatClass;

    // Prevent navigation and show alert if any required field is missing or date is invalid
    if (!origin || !destination || !flightDate) {
      window.alert('Please fill in all required fields and select a valid date.');
      return;
    }

    try {
      const params = new URLSearchParams({
        origin,
        destination,
        flightDate,
        seatClass,
      });

      const response = await fetch(`http://localhost:8082/flights/search?${params.toString()}`);
      if (!response.ok) throw new Error('No flights found');
      const flights = await response.json();

      if (!flights || flights.length === 0) {
        window.alert('No flights found for the selected criteria.');
        return;
      }

      navigate('/flight-results', {
        state: {
          searchData: formData,
          flights,
        },
      });
    } catch (err) {
      window.alert('No flights found for the selected criteria.');
      return;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Updated Header with Profile Dropdown */}
      <header className="bg-blue-900 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-xl font-extrabold bg-gradient-to-r from-blue-600 via-blue-400 to-cyan-400 bg-clip-text text-transparent tracking-wide drop-shadow-lg shadow-blue-200 flex items-center gap-2">
            <img src={logo} alt="JetSetGo Logo" className="h-8 w-8 object-contain rounded-full" />
            JetSetGo
          </h1>
          
          <Menu as="div" className="relative inline-block text-left">
            <div>
              <Menu.Button className="inline-flex items-center space-x-2 text-gray-700 hover:text-gray-900">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <UserIcon className="w-5 h-5 text-blue-600" />
                </div>
                <ChevronDownIcon className="w-4 h-4" />
              </Menu.Button>
            </div>

            <Transition
              enter="transition ease-out duration-100"
              enterFrom="transform opacity-0 scale-95"
              enterTo="transform opacity-100 scale-100"
              leave="transition ease-in duration-75"
              leaveFrom="transform opacity-100 scale-100"
              leaveTo="transform opacity-0 scale-95"
            >
              <Menu.Items className="absolute right-0 w-56 mt-2 origin-top-right bg-white divide-y divide-gray-100 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
                <div className="px-1 py-1">
                  <Menu.Item>
                    {({ active }) => (
                      <button
                        onClick={() => navigate('/profile')}
                        className={`${
                          active ? 'bg-blue-500 text-white' : 'text-gray-900'
                        } group flex rounded-md items-center w-full px-2 py-2 text-sm`}
                      >
                        <UserIcon className="w-5 h-5 mr-2" />
                        My Profile
                      </button>
                    )}
                  </Menu.Item>
                </div>
                <div className="px-1 py-1">
                  <Menu.Item>
                    {({ active }) => (
                      <button
                        onClick={onLogout}
                        className={`${
                          active ? 'bg-blue-500 text-white' : 'text-gray-900'
                        } group flex rounded-md items-center w-full px-2 py-2 text-sm`}
                      >
                        <LogoutIcon className="w-5 h-5 mr-2" />
                        Sign Out
                      </button>
                    )}
                  </Menu.Item>
                </div>
              </Menu.Items>
            </Transition>
          </Menu>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-64 md:h-96">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute top-0 left-0 w-full h-full object-cover"
          src={bgVideo}
        />
        <div className="absolute inset-0 bg-black/30 flex items-center justify-center z-10">
          <div className="text-center px-4">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Start Your Next Great Escape
            </h1>
            <p className="text-xl text-white max-w-2xl mx-auto">
              Explore incredible places without breaking the bank
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8 -mt-16 md:-mt-24 relative z-10">
        {/* Search Form Card */}
        <div className="bg-blue-50 rounded-xl shadow-lg overflow-hidden mb-16">
          <form onSubmit={handleSearch} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <AirportInput
                id="from"
                label="Source"
                value={formData.from}
                onChange={handleInputChange}
                placeholder="City"
                suggestions={suggestions.from}
                onSuggestionClick={(airport) => handleSuggestionClick('from', airport)}
                isActive={activeField === 'from'}
              />

              <SwapButton onClick={handleSwap} />

              <AirportInput
                id="to"
                label="Destination"
                value={formData.to}
                onChange={handleInputChange}
                placeholder="City"
                suggestions={suggestions.to}
                onSuggestionClick={(airport) => handleSuggestionClick('to', airport)}
                isActive={activeField === 'to'}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <DateInput
                id="flightDate"
                label="Flight Date"
                value={formData.flightDate}
                onChange={handleInputChange}
                name="flightDate"
              />

              <PassengerClassSelect
                type="seatClass"
                id="seatClass"
                label="Seat Class"
                value={formData.seatClass}
                onChange={handleInputChange}
                options={[
                  { value: 'economy', label: 'Economy' },
                  { value: 'business', label: 'Business' },
                  { value: 'first', label: 'First Class' }
                ]}
                name="seatClass"
              />
            </div>

            <div className="text-center">
              <button
                type="submit"
                className="px-8 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Search Results
              </button>
            </div>
          </form>
        </div>

        {/* Footer */}
        <footer className="bg-white py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <div className="text-center sm:text-left">
                <p className="text-sm text-gray-500">
                  &copy; 2025 Flight Management System. All rights reserved.
                </p>
              </div>
              <div className="mt-4 sm:mt-0">
                <a
                  href="#"
                  className="text-sm text-gray-500 hover:text-gray-700 transition-colors"
                >
                  Privacy Policy
                </a>
                <span className="mx-2 text-gray-400">|</span>
                <a
                  href="#"
                  className="text-sm text-gray-500 hover:text-gray-700 transition-colors"
                  onClick={e => { e.preventDefault(); navigate('/terms-and-conditions'); }}
                >
                  Terms and Conditions
                </a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default FlightSearchPage;