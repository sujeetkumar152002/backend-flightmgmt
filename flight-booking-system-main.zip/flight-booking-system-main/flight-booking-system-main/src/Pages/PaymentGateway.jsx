import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import bgImage from "../Assets/images/yo.jpg";

const PaymentGateway = () => {
  const location = useLocation();
  const deal = location.state?.deal;
  const dealAmount = location.state?.amount;

  const [amount, setAmount] = useState(dealAmount || "");
  const [orderId, setOrderId] = useState("");
  const [status, setStatus] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const loadRazorpay = async () => {
      if (!window.Razorpay) {
        const script = document.createElement("script");
        script.src = "https://checkout.razorpay.com/v1/checkout.js";
        script.async = true;
        document.body.appendChild(script);
      }
    };
    loadRazorpay();
  }, []);

  // Create payment order and open Razorpay checkout
  const handleCreatePayment = async (e) => {
    e.preventDefault();
    setStatus("");
    setMessage("");
    try {
      const res = await fetch("http://localhost:7000/api/payments/create", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ amount }),
      });
      const data = await res.json();
      if (!data.orderId) {
        setStatus("FAILED");
        setMessage("Payment creation failed: No orderId returned from backend.");
        return;
      }
      const orderId = data.orderId;
      setOrderId(orderId);
      // Open Razorpay checkout only after verifying orderId (simulate verification step)
      // You can add a real verification API call here if needed
      // For now, we assume orderId is valid and proceed
      const options = {
        key: "rzp_test_ITH8RQHQ0GTbdG", // Replace with your Razorpay key
        amount: amount * 100,
        currency: "INR",
        name: "Flight Booking",
        description: deal ? `${deal.from} → ${deal.to}` : "Flight Payment",
        order_id: orderId,
        handler: async function (response) {
          // Call backend verify API
          try {
            const verifyRes = await fetch("http://localhost:7000/api/payments/verify", {
              method: "POST",
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              body: new URLSearchParams({
                paymentId: response.razorpay_payment_id,
                orderId: response.razorpay_order_id,
                signature: response.razorpay_signature,
              }),
            });
            const verifyData = await verifyRes.json();
            if (verifyData.status === "SUCCESS") {
              setStatus("SUCCESS");
              setMessage("Payment Successful! Payment ID: " + response.razorpay_payment_id);
              // Optionally redirect to a success page:
              // window.location.href = "/payment-success";
            } else {
              setStatus("FAILED");
              setMessage("Payment verification failed at backend.");
            }
          } catch (err) {
            setStatus("FAILED");
            setMessage("Payment verification failed at backend.");
          }
        },
        prefill: {
          name: "User Name",
          email: "user@example.com",
          contact: "9999999999",
        },
        theme: {
          color: "#3399cc",
        },
      };
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      setStatus("FAILED");
      setMessage("Payment creation failed");
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{
        backgroundImage: `linear-gradient(rgba(30,64,175,0.7),rgba(30,64,175,0.7)), url(${bgImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="bg-white rounded-2xl shadow-2xl p-10 w-full max-w-lg">
        <h2 className="text-2xl font-bold mb-6 text-center">Payment Gateway</h2>
        {deal && (
          <div className="mb-6 p-4 bg-blue-50 rounded text-center">
            <div className="font-semibold text-blue-700 text-lg mb-1">
              {deal.from} → {deal.to}
            </div>
            <div className="text-gray-700 mb-1">{deal.description}</div>
            <div className="text-green-700 font-bold text-xl mb-1">
              ₹{deal.price}
            </div>
            <div className="text-sm text-gray-500">Promo: {deal.promo}</div>
          </div>
        )}
        <form onSubmit={handleCreatePayment} className="space-y-4">
          <div>
            <label className="block mb-1 font-medium">Amount (INR)</label>
            <input
              type="number"
              min="1"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full border rounded px-3 py-2"
              required
              readOnly={!!dealAmount}
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded font-semibold hover:bg-blue-700 transition"
          >
            Pay with Razorpay
          </button>
        </form>
        {status && (
          <div
            className={`mt-6 p-4 rounded text-center font-semibold ${
              status === "SUCCESS"
                ? "bg-green-100 text-green-700"
                : "bg-red-100 text-red-700"
            }`}
          >
            {message || status}
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentGateway;