import { useState, useEffect } from 'react';
import bgVideo from '../Assets/images/video.mp4';
import logo from '../Assets/images/logo.jpg';

const AdminPage = ({ onLogout }) => {
  const [showAddFlight, setShowAddFlight] = useState(false);
  const [addFlightData, setAddFlightData] = useState({
    flightId: '',
    flightDate: '',
    origin: '',
    destination: '',
    totalNoOfSeats: '',
    availableSeats: '',
    status: '',
    flightTime: '',
    seats: [], // Add seats array
  });
  const [seatInput, setSeatInput] = useState({ seatNumber: '', seatClass: '', price: '' });
  const [addFlightMsg, setAddFlightMsg] = useState('');
  const [viewOrigin, setViewOrigin] = useState('');
  const [originFlights, setOriginFlights] = useState([]);
  const [originMsg, setOriginMsg] = useState('');
  const [viewDestination, setViewDestination] = useState('');
  const [destinationFlights, setDestinationFlights] = useState([]);
  const [destinationMsg, setDestinationMsg] = useState('');
  const [viewDate, setViewDate] = useState('');
  const [dateFlights, setDateFlights] = useState([]);
  const [dateMsg, setDateMsg] = useState('');
  const [allFlights, setAllFlights] = useState([]);
  const [allMsg, setAllMsg] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [userId, setUserId] = useState('');
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    // Example: get admin email from localStorage or API
    const token = localStorage.getItem('token');
    if (token) {
      // If you store user info in localStorage, parse it here
      // For demo, just set a placeholder or decode JWT if available
      // setAdminEmail('admin@flight.com');
      // Example: decode JWT to get email (pseudo-code)
      // const decoded = jwtDecode(token); setAdminEmail(decoded.email);
      // For now, fallback to a generic label
      setAdminEmail(localStorage.getItem('adminEmail') || 'Admin User');
    }

    // Get userId and userEmail from localStorage if available
    setUserId(localStorage.getItem('userId') || '');
    setUserEmail(localStorage.getItem('userEmail') || '');
  }, []);

  const handleAddFlightChange = (e) => {
    const { name, value } = e.target;
    setAddFlightData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle seat input change
  const handleSeatInputChange = (e) => {
    const { name, value } = e.target;
    setSeatInput((prev) => ({ ...prev, [name]: value }));
  };

  // Add seat to seats array
  const handleAddSeat = (e) => {
    e.preventDefault();
    if (!seatInput.seatNumber || !seatInput.seatClass || !seatInput.price) return;
    setAddFlightData((prev) => ({
      ...prev,
      seats: [...prev.seats, { ...seatInput }],
    }));
    setSeatInput({ seatNumber: '', seatClass: '', price: '' });
  };

  // Remove seat from seats array
  const handleRemoveSeat = (idx) => {
    setAddFlightData((prev) => ({
      ...prev,
      seats: prev.seats.filter((_, i) => i !== idx),
    }));
  };

  const handleAddFlightSubmit = async (e) => {
    e.preventDefault();
    setAddFlightMsg('');
    try {
      const res = await fetch('http://localhost:8082/flights/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(addFlightData),
      });
      if (!res.ok) throw new Error('Failed to add flight');
      setAddFlightMsg('Flight added successfully!');
      setAddFlightData({
        flightId: '', flightDate: '', origin: '', destination: '', totalNoOfSeats: '', availableSeats: '', status: '', flightTime: '', seats: [],
      });
    } catch (err) {
      setAddFlightMsg('Error: ' + err.message);
    }
  };

  const handleViewByOrigin = async (e) => {
    e.preventDefault();
    setOriginMsg('');
    setOriginFlights([]);
    if (!viewOrigin) return;
    try {
      const res = await fetch(`http://localhost:8082/flights/origin/${encodeURIComponent(viewOrigin)}`);
      if (!res.ok) throw new Error('No flights found for this origin');
      const data = await res.json();
      setOriginFlights(data);
      if (data.length === 0) setOriginMsg('No flights found for this origin.');
    } catch (err) {
      setOriginMsg('Error: ' + err.message);
    }
  };

  const handleViewByDestination = async (e) => {
    e.preventDefault();
    setDestinationMsg('');
    setDestinationFlights([]);
    if (!viewDestination) return;
    try {
      const res = await fetch(`http://localhost:8082/flights/destination/${encodeURIComponent(viewDestination)}`);
      if (!res.ok) throw new Error('No flights found for this destination');
      const data = await res.json();
      setDestinationFlights(data);
      if (data.length === 0) setDestinationMsg('No flights found for this destination.');
    } catch (err) {
      setDestinationMsg('Error: ' + err.message);
    }
  };

  const handleViewByDate = async (e) => {
    e.preventDefault();
    setDateMsg('');
    setDateFlights([]);
    if (!viewDate) return;
    try {
      const res = await fetch(`http://localhost:8082/flights/flight-Date/${encodeURIComponent(viewDate)}`);
      if (!res.ok) throw new Error('No flights found for this date');
      const data = await res.json();
      setDateFlights(data);
      if (data.length === 0) setDateMsg('No flights found for this date.');
    } catch (err) {
      setDateMsg('Error: ' + err.message);
    }
  };

  const handleViewAllFlights = async () => {
    setAllMsg('');
    setAllFlights([]);
    try {
      const res = await fetch('http://localhost:8082/flights/all');
      if (!res.ok) throw new Error('No flights found');
      const data = await res.json();
      setAllFlights(data);
      if (data.length === 0) setAllMsg('No flights found.');
    } catch (err) {
      setAllMsg('Error: ' + err.message);
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden font-sans">
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute top-0 left-0 w-full h-full object-cover z-0 brightness-80 saturate-150 blur-sm"
        src={bgVideo}
      />
      {/* Overlay for readability */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/90 via-blue-100/70 to-white/90 z-0" />
      {/* Top Navigation Bar */}
      <nav className="w-full flex items-center justify-between px-8 py-4 bg-gradient-to-r from-blue-900 via-blue-800 to-blue-700/90 text-white shadow-2xl backdrop-blur-md z-10 relative">
        <div className="flex items-center gap-4">
          <img src={logo} alt="JetSetGO Logo" className="w-12 h-12 rounded-full border-2 border-blue-200 shadow-lg object-cover" />
          <span className="text-3xl font-extrabold bg-gradient-to-r from-blue-600 via-blue-400 to-cyan-400 bg-clip-text text-transparent tracking-wide drop-shadow-lg shadow-blue-200 flex items-center gap-2">JetSetGo</span>
        </div>
        <div className="flex items-center gap-6">
          {userId && <span className="text-base font-semibold text-blue-100 bg-blue-800/60 px-3 py-1 rounded-lg">UserID: {userId}</span>}
          {userEmail && <span className="text-base font-semibold text-blue-100 bg-blue-800/60 px-3 py-1 rounded-lg">Email: {userEmail}</span>}
          <button
            onClick={onLogout}
            className="px-6 py-2 bg-gradient-to-r from-blue-200 to-blue-400 text-blue-900 rounded-lg hover:from-blue-300 hover:to-blue-500 transition-colors font-bold shadow-lg"
          >
            Sign Out
          </button>
        </div>
      </nav>
      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto py-12 px-4 sm:px-8 lg:px-12 flex flex-col gap-10 relative z-10 w-full">
        {/* Add Flight Box */}
        <div className="w-full max-w-2xl bg-white/95 shadow-2xl rounded-3xl overflow-hidden flex flex-col mx-auto border border-blue-100 backdrop-blur-md">
          <div className="p-8 flex flex-col justify-center">
            <h2 className="text-3xl font-extrabold mb-6 text-blue-800 drop-shadow">Add New Flight</h2>
            <form onSubmit={handleAddFlightSubmit} className="space-y-4">
              <div className="grid grid-cols-1 gap-3">
                <input name="flightId" value={addFlightData.flightId} onChange={handleAddFlightChange} placeholder="Flight Id" className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required />
                <input name="flightDate" type="date" value={addFlightData.flightDate} onChange={handleAddFlightChange} placeholder="Flight Date" className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required />
                <input name="origin" value={addFlightData.origin} onChange={handleAddFlightChange} placeholder="Origin" className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required />
                <input name="destination" value={addFlightData.destination} onChange={handleAddFlightChange} placeholder="Destination" className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required />
                <input name="totalNoOfSeats" type="number" min="1" value={addFlightData.totalNoOfSeats} onChange={handleAddFlightChange} placeholder="Total No Of Seats" className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required />
                <input name="availableSeats" type="number" min="0" value={addFlightData.availableSeats} onChange={handleAddFlightChange} placeholder="Available Seats" className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required />
                <select name="status" value={addFlightData.status} onChange={handleAddFlightChange} className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required>
                  <option value="">Select Status</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="delayed">Delayed</option>
                  <option value="cancelled">Cancelled</option>
                  <option value="completed">Completed</option>
                </select>
                <input name="flightTime" type="time" value={addFlightData.flightTime} onChange={handleAddFlightChange} placeholder="Flight Time" className="border px-4 py-2 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-200 text-lg" required />
              </div>
              {/* Add Seats Section */}
              <div className="mt-6 bg-blue-50 rounded-xl p-4 border border-blue-200">
                <div className="font-semibold text-blue-700 mb-2">Add Seats</div>
                <div className="flex flex-col md:flex-row gap-2 mb-2">
                  <input name="seatNumber" value={seatInput.seatNumber} onChange={handleSeatInputChange} placeholder="Seat Number" className="border px-3 py-2 rounded w-full" />
                  <select name="seatClass" value={seatInput.seatClass} onChange={handleSeatInputChange} className="border px-3 py-2 rounded w-full">
                    <option value="">Class</option>
                    <option value="Economy">Economy</option>
                    <option value="Business">Business</option>
                    <option value="First">First</option>
                  </select>
                  <input name="price" type="number" min="0" value={seatInput.price} onChange={handleSeatInputChange} placeholder="Price" className="border px-3 py-2 rounded w-full" />
                  <button onClick={handleAddSeat} className="bg-blue-600 text-white px-4 py-2 rounded font-semibold hover:bg-blue-700 transition" type="button">Add</button>
                </div>
                {/* List of added seats */}
                {addFlightData.seats.length > 0 && (
                  <div className="max-h-32 overflow-y-auto mt-2">
                    <table className="min-w-full text-xs">
                      <thead>
                        <tr className="bg-blue-100">
                          <th className="px-2 py-1">Seat #</th>
                          <th className="px-2 py-1">Class</th>
                          <th className="px-2 py-1">Price</th>
                          <th className="px-2 py-1">Remove</th>
                        </tr>
                      </thead>
                      <tbody>
                        {addFlightData.seats.map((seat, idx) => (
                          <tr key={idx} className="bg-white even:bg-blue-50">
                            <td className="px-2 py-1">{seat.seatNumber}</td>
                            <td className="px-2 py-1">{seat.seatClass}</td>
                            <td className="px-2 py-1">{seat.price}</td>
                            <td className="px-2 py-1">
                              <button type="button" onClick={() => handleRemoveSeat(idx)} className="text-red-600 font-bold">X</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
              <button type="submit" className="bg-gradient-to-r from-green-500 to-green-700 text-white px-6 py-2 rounded-lg font-bold hover:from-green-600 hover:to-green-800 transition shadow-xl">Add Flight</button>
              {addFlightMsg && <div className="mt-2 text-center text-base font-semibold text-blue-700">{addFlightMsg}</div>}
            </form>
          </div>
        </div>
        {/* Search Boxes Row */}
        <div className="w-full flex flex-col lg:flex-row gap-8 justify-center items-start">
          {/* View Flights by Source Box */}
          <div className="flex-1 max-w-xs bg-blue-50 shadow-lg rounded-lg p-6 border-2 border-blue-200">
            <h2 className="text-xl font-bold mb-4 text-blue-800">View by Source</h2>
            <form onSubmit={handleViewByOrigin} className="flex gap-2 mb-4">
              <input
                type="text"
                value={viewOrigin}
                onChange={e => setViewOrigin(e.target.value)}
                placeholder="Origin"
                className="border px-3 py-2 rounded w-full"
                required
              />
              <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded font-semibold hover:bg-blue-700 transition">View</button>
            </form>
            {originMsg && <div className="text-center text-red-600 mb-2">{originMsg}</div>}
            {originFlights.length > 0 && (
              <div className="overflow-x-auto max-h-48">
                <table className="min-w-full divide-y divide-gray-200 text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-2">Flight Id</th>
                      <th className="px-4 py-2">Date</th>
                      <th className="px-4 py-2">Origin</th>
                      <th className="px-4 py-2">Destination</th>
                      <th className="px-4 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {originFlights.map(flight => (
                      <tr key={flight.id || flight.flightId}>
                        <td className="px-4 py-2">{flight.flightId}</td>
                        <td className="px-4 py-2">{flight.flightDate}</td>
                        <td className="px-4 py-2">{flight.origin}</td>
                        <td className="px-4 py-2">{flight.destination}</td>
                        <td className="px-4 py-2">{flight.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          {/* View Flights by Destination Box */}
          <div className="flex-1 max-w-xs bg-green-50 shadow-lg rounded-lg p-6 border-2 border-green-200">
            <h2 className="text-xl font-bold mb-4 text-green-800">View by Destination</h2>
            <form onSubmit={handleViewByDestination} className="flex gap-2 mb-4">
              <input
                type="text"
                value={viewDestination}
                onChange={e => setViewDestination(e.target.value)}
                placeholder="Destination"
                className="border px-3 py-2 rounded w-full"
                required
              />
              <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded font-semibold hover:bg-green-700 transition">View</button>
            </form>
            {destinationMsg && <div className="text-center text-red-600 mb-2">{destinationMsg}</div>}
            {destinationFlights.length > 0 && (
              <div className="overflow-x-auto max-h-48">
                <table className="min-w-full divide-y divide-gray-200 text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-2">Flight Id</th>
                      <th className="px-4 py-2">Date</th>
                      <th className="px-4 py-2">Origin</th>
                      <th className="px-4 py-2">Destination</th>
                      <th className="px-4 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {destinationFlights.map(flight => (
                      <tr key={flight.id || flight.flightId}>
                        <td className="px-4 py-2">{flight.flightId}</td>
                        <td className="px-4 py-2">{flight.flightDate}</td>
                        <td className="px-4 py-2">{flight.origin}</td>
                        <td className="px-4 py-2">{flight.destination}</td>
                        <td className="px-4 py-2">{flight.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          {/* View Flights by Date Box */}
          <div className="flex-1 max-w-xs bg-yellow-50 shadow-lg rounded-lg p-6 border-2 border-yellow-200">
            <h2 className="text-xl font-bold mb-4 text-yellow-800">View by Date</h2>
            <form onSubmit={handleViewByDate} className="flex gap-2 mb-4">
              <input
                type="date"
                value={viewDate}
                onChange={e => setViewDate(e.target.value)}
                className="border px-3 py-2 rounded w-full"
                required
              />
              <button type="submit" className="bg-yellow-500 text-white px-4 py-2 rounded font-semibold hover:bg-yellow-600 transition">View</button>
            </form>
            {dateMsg && <div className="text-center text-red-600 mb-2">{dateMsg}</div>}
            {dateFlights.length > 0 && (
              <div className="overflow-x-auto max-h-48">
                <table className="min-w-full divide-y divide-gray-200 text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-2">Flight Id</th>
                      <th className="px-4 py-2">Date</th>
                      <th className="px-4 py-2">Origin</th>
                      <th className="px-4 py-2">Destination</th>
                      <th className="px-4 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {dateFlights.map(flight => (
                      <tr key={flight.id || flight.flightId}>
                        <td className="px-4 py-2">{flight.flightId}</td>
                        <td className="px-4 py-2">{flight.flightDate}</td>
                        <td className="px-4 py-2">{flight.origin}</td>
                        <td className="px-4 py-2">{flight.destination}</td>
                        <td className="px-4 py-2">{flight.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          {/* View All Flights Box */}
          <div className="flex-1 max-w-xs bg-purple-50 shadow-lg rounded-lg p-6 border-2 border-purple-200">
            <h2 className="text-xl font-bold mb-4 text-purple-800">View All Flights</h2>
            <button
              onClick={handleViewAllFlights}
              className="bg-purple-600 text-white px-4 py-2 rounded font-semibold hover:bg-purple-700 transition mb-4"
            >
              View All Flights
            </button>
            {allMsg && <div className="text-center text-red-600 mb-2">{allMsg}</div>}
            {allFlights.length > 0 && (
              <div className="overflow-x-auto max-h-48">
                <table className="min-w-full divide-y divide-gray-200 text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-2">Flight Id</th>
                      <th className="px-4 py-2">Date</th>
                      <th className="px-4 py-2">Origin</th>
                      <th className="px-4 py-2">Destination</th>
                      <th className="px-4 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {allFlights.map(flight => (
                      <tr key={flight.id || flight.flightId}>
                        <td className="px-4 py-2">{flight.flightId}</td>
                        <td className="px-4 py-2">{flight.flightDate}</td>
                        <td className="px-4 py-2">{flight.origin}</td>
                        <td className="px-4 py-2">{flight.destination}</td>
                        <td className="px-4 py-2">{flight.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminPage;