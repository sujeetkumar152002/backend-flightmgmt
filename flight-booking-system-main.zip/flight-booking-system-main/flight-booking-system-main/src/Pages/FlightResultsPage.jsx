import { useState, useEffect, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { FiArrowLeft, FiClock, FiStar, FiChevronRight, FiInfo, FiFrown } from 'react-icons/fi';
import { motion, AnimatePresence } from 'framer-motion';
import airplaneImage from '../Assets/images/airplane-icon.jpg';
import luggageImage from '../Assets/images/luggage-icon.png';
import mealImage from '../Assets/images/meal-icon.png';
import flightBg from '../Assets/images/flight-booking-hero.jpg';

const FlightResultsPage = ({ onBack }) => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const searchData = state?.searchData || {};
  const flights = state?.flights || [];

  // Store seat prices by seatId
  const [seatPrices, setSeatPrices] = useState({});

  // Fetch seat price for a given seatId if not already fetched
  const fetchSeatPrice = async (seatId) => {
    if (!seatId || seatPrices[seatId] !== undefined) return;
    try {
      const res = await fetch(`http://localhost:8082/price/id/${seatId}`);
      if (res.ok) {
        const price = await res.json();
        setSeatPrices((prev) => ({ ...prev, [seatId]: price }));
      }
    } catch (e) {
      setSeatPrices((prev) => ({ ...prev, [seatId]: 'N/A' }));
    }
  };

  const [selectedSeatClass, setSelectedSeatClass] = useState({}); // { [flightId]: seatClass }

  // Fetch price by seat class
  const fetchPriceByClass = async (flightId, seatClass) => {
    if (!flightId || !seatClass) return;
    const key = `${flightId}_${seatClass}`;
    if (seatPrices[key] !== undefined) return;
    try {
      // Use the correct endpoint as per your prompt
      const res = await fetch(`http://localhost:8082/flights/price-by-class/${seatClass}`);
      if (res.ok) {
        const price = await res.json();
        setSeatPrices((prev) => ({ ...prev, [key]: price }));
      } else {
        setSeatPrices((prev) => ({ ...prev, [key]: 'N/A' }));
      }
    } catch (e) {
      setSeatPrices((prev) => ({ ...prev, [key]: 'N/A' }));
    }
  };

  useEffect(() => {
    if (flights.length === 0) {
      // Show a pop-up message if no flights found
      window.alert('No flights found for your search.');
    }
  }, [flights]);

  const [expandedFlight, setExpandedFlight] = useState(null);
  const [sortBy, setSortBy] = useState('price');
  const [filteredFlights, setFilteredFlights] = useState(flights);

  // Map searchData fields to match new search (flightDate, seatClass)
  const from = searchData.from || '';
  const to = searchData.to || '';
  const flightDate = searchData.flightDate || '';
  const seatClass = searchData.seatClass || '';

  useEffect(() => {
    // Sort flights based on user preference
    const sorted = [...flights].sort((a, b) => {
      if (sortBy === 'price') {
        // If price is a number, use it directly; else, parse it
        const priceA = typeof a.price === 'number' ? a.price : parseInt(a.price.replace(/[^\d]/g, ''));
        const priceB = typeof b.price === 'number' ? b.price : parseInt(b.price.replace(/[^\d]/g, ''));
        return priceA - priceB;
      } else if (sortBy === 'duration') {
        return (a.duration || '').localeCompare(b.duration || '');
      } else {
        return (a.departureTime || '').localeCompare(b.departureTime || '');
      }
    });
    setFilteredFlights(sorted);
  }, [sortBy, flights]);

  const handleBookNow = (flight) => {
    navigate('/booking-details', { state: { flight, searchData } });
  };

  const toggleFlightDetails = (flightId) => {
    setExpandedFlight(expandedFlight === flightId ? null : flightId);
  };

  // Animation variants
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.3 }
    },
    hover: { scale: 1.02 }
  };

  const detailsVariants = {
    hidden: { opacity: 0, height: 0 },
    visible: { 
      opacity: 1, 
      height: 'auto',
      transition: { duration: 0.3 }
    }
  };

  // India-specific airline data
  const indianAirlines = {
    'Air India': {
      logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/9/9b/Air_India_Logo.svg/1200px-Air_India_Logo.svg.png',
      meals: ['Vegetarian Thali', 'Non-vegetarian option', 'Indian snacks'],
      baggage: '25kg checked + 7kg cabin'
    },
    'IndiGo': {
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/IndiGo_Logo.svg/1200px-IndiGo_Logo.svg.png',
      meals: ['Buy-on-board options', 'Indian snacks available'],
      baggage: '15kg checked + 7kg cabin (basic fare)'
    },
    'Vistara': {
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Vistara_logo.svg/1200px-Vistara_logo.svg.png',
      meals: ['Hot meals included', 'Vegetarian options', 'Special meals on request'],
      baggage: '25kg checked + 7kg cabin'
    },
    'SpiceJet': {
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/SpiceJet_Logo.svg/1200px-SpiceJet_Logo.svg.png',
      meals: ['Buy-on-board options', 'Indian snacks'],
      baggage: '15kg checked + 7kg cabin'
    },
    'Akasa Air': {
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Akasa_Air_Logo.svg/1200px-Akasa_Air_Logo.svg.png',
      meals: ['Complimentary snacks', 'Beverages'],
      baggage: '15kg checked + 7kg cabin'
    }
  };

  return (
    <div
      className="min-h-screen relative"
      style={{
        backgroundImage: `url(${flightBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Overlay for better readability */}
      <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-0"></div>

      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden z-0 pointer-events-none">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-blue-100 rounded-full opacity-10"
            style={{
              width: Math.random() * 200 + 100,
              height: Math.random() * 200 + 100,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              x: [0, Math.random() * 100 - 50],
              y: [0, Math.random() * 100 - 50],
            }}
            transition={{
              duration: Math.random() * 20 + 10,
              repeat: Infinity,
              repeatType: 'reverse',
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="bg-white shadow-lg relative z-10">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <motion.button
              onClick={onBack}
              className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
              whileHover={{ x: -3 }}
            >
              <FiArrowLeft className="mr-2" />
              <span className="font-medium">Back to search</span>
            </motion.button>
            <motion.h1 
              className="text-2xl font-bold text-gray-900"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <span className="text-blue-600">{from}</span> 
              <FiChevronRight className="inline mx-2 text-gray-400" /> 
              <span className="text-blue-600">{to}</span>
            </motion.h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          {/* Search Summary Card */}
          <motion.div 
            className="bg-white rounded-2xl shadow-xl p-6 mb-8 border border-gray-100"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div className="mb-4 md:mb-0">
                <h2 className="text-xl font-bold text-gray-800 mb-3">Trip</h2>
                <div className="flex items-center space-x-4">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-2 rounded-lg shadow-sm">
                    <div className="text-sm font-medium">Flight Date</div>
                    <div className="font-bold">{flightDate}</div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center bg-gray-100 px-4 py-2 rounded-full">
                  <FiStar className="mr-2 text-yellow-500" />
                  <span className="font-medium capitalize">{seatClass}</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Sorting Controls */}
          <motion.div
            className="bg-white rounded-lg shadow-sm p-4 mb-6 flex flex-wrap items-center justify-between gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <div className="font-medium text-gray-700">Sort by:</div>
            <div className="flex flex-wrap gap-2">
              {['price', 'duration', 'departure'].map((option) => (
                <button
                  key={option}
                  onClick={() => setSortBy(option)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    sortBy === option
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {option.charAt(0).toUpperCase() + option.slice(1)}
                </button>
              ))}
            </div>
            <div className="text-sm text-gray-500">
              {filteredFlights.length} flights found
            </div>
          </motion.div>

          {/* Flight Results */}
          <div className="grid gap-6">
            <AnimatePresence>
              {filteredFlights.map((flight) => {
                const airlineInfo = indianAirlines[flight.airline] || {
                  logo: airplaneImage,
                  meals: ['Complimentary meal', 'Vegetarian options'],
                  baggage: '20kg checked + 7kg cabin'
                };
                // Use backend-provided status if available, else fallback
                const status = flight.status || 'On Time';
                // Use backend-provided flight time (duration or flightTime)
                const flightTime = flight.duration || flight.flightTime || '';
                // Use numeric flightId for fetching and displaying available seats
                const flightId = typeof flight.flightId === 'number' ? flight.flightId : Number(flight.flightId);
                // Use seatClass from searchData (already selected in FlightSearchPage)
                const priceKey = `${flight.flightId}_${seatClass}`;
                // Fetch price by seatClass if not already fetched
                if (seatPrices[priceKey] === undefined) fetchPriceByClass(flight.flightId, seatClass);

                return (
                <motion.div
                  key={flight.id}
                  className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100"
                  variants={cardVariants}
                  initial="hidden"
                  animate="visible"
                  whileHover="hover"
                  layout
                >
                  <div className="p-6">
                    <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center space-y-6 lg:space-y-0">
                      {/* Airline Info */}
                      <div className="flex items-center">
                        <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center mr-4 shadow-md border border-gray-200 overflow-hidden">
                          <img 
                            src={airlineInfo.logo} 
                            alt="Airline" 
                            className="w-full h-full object-contain object-center"
                            style={{ maxWidth: '100%', maxHeight: '100%' }}
                          />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-900">{flight.airline}</h3>
                          <p className="text-gray-500">Flight ID: {flight.flightId}</p>
                        </div>
                      </div>

                      {/* Flight Timeline + Time/Status */}
                      <div className="flex-1 px-4 lg:px-8">
                        <div className="flex items-center justify-between">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-gray-900">{flight.departureTime}</div>
                            <div className="text-sm text-gray-500 mt-1">{from}</div>
                          </div>
                          <div className="flex flex-col items-center px-4">
                            <div className="text-xs text-gray-500 mb-1">{flight.duration}</div>
                            <div className="relative w-32">
                              <div className="h-px bg-gray-300 w-full absolute top-1/2"></div>
                              <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                                <FiClock className="text-blue-500 bg-white p-1 rounded-full border border-blue-100" />
                              </div>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">{flight.stops || 'Non-stop'}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-gray-900">{flight.arrivalTime}</div>
                            <div className="text-sm text-gray-500 mt-1">{to}</div>
                          </div>
                        </div>
                        {/* Flight Time and Status only (no available seats) */}
                        <div className="flex flex-wrap gap-4 mt-4 justify-center lg:justify-start">
                          <div className="flex items-center bg-blue-50 px-3 py-1 rounded-full text-blue-700 text-sm font-medium">
                            <FiClock className="mr-1" /> Flight Time: {flightTime}
                          </div>
                          <div className={`flex items-center px-3 py-1 rounded-full text-sm font-medium ${status === 'On Time' ? 'bg-green-50 text-green-700' : status === 'Delayed' ? 'bg-yellow-50 text-yellow-700' : 'bg-red-50 text-red-700'}`}> 
                            <FiInfo className="mr-1" /> Status: {status}
                          </div>
                        </div>
                      </div>

                      {/* Price and Booking */}
                      <div className="flex flex-col items-end">
                        <div className="text-3xl font-bold text-gray-900 mb-2">
                          {seatPrices[priceKey] !== undefined && seatPrices[priceKey] !== 'N/A' ? (
                            <>₹{seatPrices[priceKey]}</>
                          ) : seatPrices[priceKey] === 'N/A' ? (
                            <span>Price not available</span>
                          ) : (
                            <span className="text-gray-400">Fetching...</span>
                          )}
                        </div>
                        <button
                          onClick={() => handleBookNow({ ...flight, seatClass, price: seatPrices[priceKey] })}
                          className="px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-medium rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg"
                          disabled={seatPrices[priceKey] === undefined || seatPrices[priceKey] === 'N/A'}
                        >
                          Select Flight
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Expandable Details - India Specific */}
                  <motion.div
                    variants={detailsVariants}
                    initial="hidden"
                    animate={expandedFlight === flight.id ? "visible" : "hidden"}
                    className="overflow-hidden"
                  >
                    <div className="border-t border-gray-100 p-6 bg-gray-50">
                      <div className="grid md:grid-cols-3 gap-6">
                        <div className="flex items-start">
                          <img src={luggageImage} alt="Baggage" className="w-8 h-8 mr-3 mt-1" />
                          <div>
                            <h4 className="font-bold text-gray-800 mb-1">Baggage Allowance</h4>
                            <p className="text-gray-600">{airlineInfo.baggage}</p>
                            <p className="text-gray-600 text-sm mt-1">Excess baggage: ₹500/kg</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <img src={mealImage} alt="Meal" className="w-8 h-8 mr-3 mt-1" />
                          <div>
                            <h4 className="font-bold text-gray-800 mb-1">Meal Service</h4>
                            {airlineInfo.meals.map((meal, i) => (
                              <p key={i} className="text-gray-600">{meal}</p>
                            ))}
                            <p className="text-gray-600 text-sm mt-1">Special meals available 24hrs before flight</p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <FiInfo className="text-blue-500 w-8 h-8 mr-3 mt-1" />
                          <div>
                            <h4 className="font-bold text-gray-800 mb-1">Flight Details</h4>
                            <p className="text-gray-600">Aircraft: {['Airbus A320', 'Boeing 737', 'Airbus A321'][Math.floor(Math.random() * 3)]}</p>
                            <p className="text-gray-600">Entertainment: {flight.airline === 'Air India' || flight.airline === 'Vistara' ? 'Personal screens with Bollywood movies' : 'Buy-on-board options'}</p>
                          </div>
                        </div>
                      </div>
                      <div className="mt-6 pt-4 border-t border-gray-200">
                        <h4 className="font-bold text-gray-800 mb-2">India Travel Information</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium">Check-in:</span> Opens 48 hours before departure
                          </div>
                          <div>
                            <span className="font-medium">Web Check-in:</span> Mandatory for all passengers
                          </div>
                          <div>
                            <span className="font-medium">COVID Guidelines:</span>{' '}
                            <button
                              className="text-blue-600 underline hover:text-blue-800 font-medium"
                              onClick={() => navigate('/covid-guidelines')}
                              type="button"
                            >
                              View Guidelines
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  {/* Toggle Details Button */}
                  <div className="border-t border-gray-100 text-center">
                    <button
                      onClick={() => toggleFlightDetails(flight.id)}
                      className="w-full py-3 text-blue-600 hover:text-blue-800 font-medium flex items-center justify-center"
                    >
                      {expandedFlight === flight.id ? 'Hide details' : 'Show flight details'}
                      <FiChevronRight className={`ml-2 transition-transform ${
                        expandedFlight === flight.id ? 'transform rotate-90' : ''
                      }`} />
                    </button>
                  </div>
                </motion.div>
                )
              })}
            </AnimatePresence>
          </div>

          {/* No Results */}
          {filteredFlights.length === 0 && (
            <motion.div
              className="bg-white rounded-2xl shadow-xl p-8 text-center border border-gray-100"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <FiFrown className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No flights found</h3>
              <p className="text-gray-500 mb-6 max-w-md mx-auto">
                We couldn't find any flights matching your criteria. Try adjusting your search filters or check flights from nearby airports.
              </p>
              <motion.button
                onClick={onBack}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-medium rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Modify Search
              </motion.button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FlightResultsPage;