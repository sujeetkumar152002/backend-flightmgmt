import React, { useState } from "react";
import bgVideo from "../Assets/images/avideo.mp4";

const Checkin = () => {
  const [bookingId, setBookingId] = useState("");
  const [message, setMessage] = useState("");

  const handleCheckin = (e) => {
    e.preventDefault();
    setMessage(`✅ Check-in successful for Booking ID: ${bookingId}`);
  };

  const handleCancel = () => {
    setMessage(`❌ Booking ID ${bookingId} has been cancelled.`);
  };

  const handleUpdate = () => {
    setMessage(`✏️ Booking ID ${bookingId} has been updated.`);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute top-0 left-0 w-full h-full object-cover z-0 brightness-75"
        src={bgVideo}
      />
      {/* Overlay for readability */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/70 via-blue-800/60 to-cyan-700/50 z-10"></div>
      <div className="w-full max-w-3xl relative z-20">
        <div className="rounded-2xl shadow-2xl bg-white/90 backdrop-blur-md p-8 md:p-12">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-cyan-500 to-green-400 drop-shadow-lg">
            ✈️ Web Check-in
          </h1>
          <p className="text-lg md:text-xl text-center text-gray-700 mb-8">
            Experience a seamless and fast check-in process for your next flight.
          </p>
          <div className="flex flex-col md:flex-row gap-6 mb-8">
            <div className="bg-gradient-to-br from-blue-100 via-cyan-100 to-green-50 rounded-xl shadow p-6 text-gray-700 text-base flex-1 border border-blue-200">
              <strong className="text-blue-700">Web Check-in:</strong>
              <br />
              <span>
                Available{" "}
                <span className="font-semibold text-blue-700">
                  48 hrs to 60 mins
                </span>{" "}
                before domestic flight departures, and{" "}
                <span className="font-semibold text-blue-700">
                  24 hrs to 75 mins
                </span>{" "}
                before international flight departures.
              </span>
            </div>
            <div className="bg-gradient-to-br from-green-100 via-blue-50 to-cyan-50 rounded-xl shadow p-6 text-gray-700 text-base flex-1 border border-green-200">
              <strong className="text-green-700">Airport Check-in:</strong>
              <br />
              <span>
                Available up to{" "}
                <span className="font-semibold text-green-700">60 mins</span>{" "}
                before domestic and{" "}
                <span className="font-semibold text-green-700">75 mins</span> before
                international departures.
              </span>
            </div>
          </div>

          <div className="bg-blue-50 rounded-xl shadow p-6 mb-8 border-l-4 border-blue-400">
            <span className="font-bold text-blue-800 block mb-2">PLEASE NOTE</span>
            <span className="text-gray-700">
              Personalized check-in assistance at the airport is applicable only for{" "}
              <span className="font-semibold">codeshare bookings</span>.
            </span>
          </div>

          <div className="bg-white rounded-xl shadow p-6 mb-10 border border-gray-100">
            <h2 className="text-2xl font-bold mb-2 text-blue-900 text-center">
              Schedule Your Check-in
            </h2>
            <div className="text-lg font-semibold mb-2 text-center">
              Get your{" "}
              <span className="text-green-600">boarding pass</span> instantly!
            </div>
            <ul className="list-disc pl-6 text-gray-700 mb-2 text-base">
              <li>Schedule your web check-in beforehand.</li>
              <li>Receive your boarding pass on WhatsApp.</li>
            </ul>
          </div>

          <div className="bg-gradient-to-br from-blue-100 via-cyan-50 to-green-50 rounded-xl shadow p-8 border border-blue-200">
            <h2 className="text-2xl font-bold mb-6 text-blue-900 text-center tracking-wide">
              Flight Check-in
            </h2>
            <form onSubmit={handleCheckin} className="space-y-6">
              <div>
                <label className="block font-semibold mb-2 text-gray-700 text-lg">
                  Booking ID
                </label>
                <input
                  type="text"
                  className="w-full border-2 border-blue-200 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-400 text-lg bg-white/80"
                  value={bookingId}
                  onChange={(e) => setBookingId(e.target.value)}
                  required
                  placeholder="Enter your Booking ID"
                />
              </div>
              <div className="flex flex-col md:flex-row gap-4 mt-2">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-500 text-white py-3 rounded-lg font-semibold shadow hover:from-blue-700 hover:to-cyan-600 transition-all text-lg"
                >
                  Check-in
                </button>
                <button
                  type="button"
                  onClick={handleUpdate}
                  className="flex-1 bg-gradient-to-r from-yellow-400 to-yellow-500 text-white py-3 rounded-lg font-semibold shadow hover:from-yellow-500 hover:to-yellow-600 transition-all text-lg"
                >
                  Update Booking
                </button>
                <button
                  type="button"
                  onClick={handleCancel}
                  className="flex-1 bg-gradient-to-r from-red-500 to-pink-500 text-white py-3 rounded-lg font-semibold shadow hover:from-red-600 hover:to-pink-600 transition-all text-lg"
                >
                  Cancel Booking
                </button>
              </div>
            </form>
            {message && (
              <div className="mt-8 text-center text-lg font-semibold text-green-700 bg-green-50 rounded-lg py-3 px-4 shadow">
                {message}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkin;
