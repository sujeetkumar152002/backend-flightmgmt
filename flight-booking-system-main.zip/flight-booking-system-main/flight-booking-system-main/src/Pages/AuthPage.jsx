import { useState } from "react";
import AuthForm from "../Components/AuthForm";
import flightImage from "../Assets/fimage3.jpg";
import logingif from "../Assets/images/logingif.gif";
import bgVideo from "../Assets/images/video.mp4";
import logo from "../Assets/images/logo.jpg";

const AuthPage = ({ setIsLoggedIn, setIsAdmin }) => {
  const [activeTab, setActiveTab] = useState("login");
  const [error, setError] = useState(null);
  const [showAdminLogin, setShowAdminLogin] = useState(false);

  const handleSubmit = async (formData) => {
    setError(null);

    try {
      if (showAdminLogin) {
        // Admin Login (uses /auth/login)
        const response = await fetch("http://localhost:9999/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: formData.email,
            password: formData.password,
          }),
        });

        if (!response.ok) {
          const errorData = await response.text();
          throw new Error(errorData || "Invalid admin credentials");
        }

        const token = await response.text();
        localStorage.setItem("token", token);
        setIsAdmin(true);
        setIsLoggedIn(true);
      } else {
        if (activeTab === "login") {
          // User Login (uses /auth/login)
          const response = await fetch("http://localhost:9999/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              email: formData.email,
              password: formData.password,
            }),
          });

          if (!response.ok) {
            const errorData = await response.text();
            throw new Error(errorData || "Invalid credentials");
          }

          const token = await response.text();
          localStorage.setItem("token", token);
          setIsLoggedIn(true);

          // After successful login
          const usersRes = await fetch("http://localhost:7000/api/users");
          const users = await usersRes.json();
          const user = users.find((u) => u.email === formData.email);

          if (!user || user.role !== "USER") {
            setError("Only users can log in here.");
            return;
          }
          // Proceed to user dashboard or homepage
        } else {
          // User Registration (uses /auth/register)
          const response = await fetch("http://localhost:9999/auth/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              username: formData.username,
              email: formData.email,
              password: formData.password,
              role: "USER",
            }),
          });

          if (!response.ok) {
            // Try to parse validation errors
            let errorMsg = "Registration failed";
            try {
              const errorData = await response.json();
              if (Array.isArray(errorData) && errorData[0]?.defaultMessage) {
                errorMsg = errorData[0].defaultMessage;
              } else if (typeof errorData === "string") {
                errorMsg = errorData;
              }
            } catch {
              // fallback to default
            }
            throw new Error(errorMsg);
          }

          setActiveTab("login");
        }
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute top-0 left-0 w-full h-full object-cover z-0"
        src={bgVideo}
      />
      {/* Overlay for gradient effect */}
      <div className="absolute top-0 left-0 w-full h-full z-10" style={{background: "linear-gradient(rgba(143, 153, 186, 0.7),rgba(30,64,175,0.7))"}} />
      <div className="flex flex-col md:flex-row bg-white rounded-2xl shadow-2xl overflow-hidden relative z-20 m-auto" style={{backdropFilter: 'blur(8px)'}}>
        {/* Login GIF */}
        <div className="flex flex-col items-center justify-center bg-white-50 p-8">
          <img
            src={logo}
            alt="JetSetGo Logo"
            className="h-24 w-24 object-contain mb-4 rounded-full shadow"
          />
          <img
            src={logingif}
            alt="Login Animation"
            className="w-64 h-64 object-contain"
          />
        </div>

        <div className="w-full max-w-md rounded-xl shadow-xl overflow-hidden backdrop-blur-sm" style={{ backgroundColor: '#e0f2fe' }}>
          <div className="p-8">
            {!showAdminLogin ? (
              <>
                <div className="flex border-b border-gray-200 mb-8">
                  <button
                    className={`py-3 px-6 font-medium text-sm focus:outline-none transition-all duration-300 ${
                      activeTab === "login"
                        ? "text-blue-600 border-b-2 border-blue-600"
                        : "text-gray-500 hover:text-gray-700"
                    }`}
                    onClick={() => setActiveTab("login")}
                  >
                    Login
                  </button>
                  <button
                    className={`py-3 px-6 font-medium text-sm focus:outline-none transition-all duration-300 ${
                      activeTab === "signup"
                        ? "text-blue-600 border-b-2 border-blue-600"
                        : "text-gray-500 hover:text-gray-700"
                    }`}
                    onClick={() => setActiveTab("signup")}
                  >
                    Sign Up
                  </button>
                </div>

                <div className="mb-8">
                  <h1 className="text-3xl font-bold text-gray-800 mb-2">
                    {activeTab === "login"
                      ? "Great to see you! We missed you!"
                      : "Get started"}
                  </h1>
                  <p className="text-gray-500">
                    {activeTab === "login"
                      ? "Sign in to access your account"
                      : "Create an account to book your flights"}
                  </p>
                </div>

                <AuthForm
                  isLogin={activeTab === "login"}
                  onSubmit={handleSubmit}
                  error={error}
                />

                <div className="mt-6 text-center">
                  <button
                    type="button"
                    onClick={() => setShowAdminLogin(true)}
                    className="text-sm text-blue-600 hover:text-blue-500 font-medium"
                  >
                    Admin Login
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="mb-8">
                  <h1 className="text-3xl font-bold text-gray-800 mb-2">
                    Admin Portal
                  </h1>
                  <p className="text-gray-500">
                    Enter your admin credentials to access the dashboard
                  </p>
                </div>

                <AuthForm
                  isLogin={true}
                  isAdmin={true}
                  onSubmit={handleSubmit}
                  error={error}
                />

                <div className="mt-6 text-center">
                  <button
                    type="button"
                    onClick={() => setShowAdminLogin(false)}
                    className="text-sm text-blue-600 hover:text-blue-500 font-medium"
                  >
                    Back to User Login
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;