// src/pages/ProfilePage.js
import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeftIcon, CalendarIcon, ClockIcon, TicketIcon , UserIcon} from '@heroicons/react/outline';
import bgFlightLight from '../Assets/images/flight-booking-hero.jpg'; // Use your flight/plane image


const ProfilePage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('current');

  // Add state for editable fields
  const [gender, setGender] = useState('Male');
  const [maritalStatus, setMaritalStatus] = useState('Single');
  const [state, setState] = useState('Maharashtra');

  // User info state
  const [userInfo, setUserInfo] = useState({ username: '', email: '' });

  useEffect(() => {
    // Example: get user info from localStorage or API
    // If you store user info in localStorage, parse it here
    // For now, fallback to a generic label
    const username = localStorage.getItem('username') || '';
    const email = localStorage.getItem('email') || '';
    setUserInfo({ username, email });
  }, []);

  // Mock booking data
  const bookings = {
    current: [
    ],
    past: [
      
    ]
  };

  return (
    <div
      className="min-h-screen bg-gray-50 relative"
      style={{
        backgroundImage: `url(${bgFlightLight})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Overlay for readability */}
      <div className="absolute inset-0 bg-white/70 z-0"></div>
      <div className="relative z-10">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex items-center">
            <button 
              onClick={() => navigate(-1)}
              className="mr-4 p-1 rounded-full hover:bg-gray-100"
            >
              <ArrowLeftIcon className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">Profile Management</h1>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Profile Summary */}
          <div className="bg-white shadow rounded-lg overflow-hidden mb-8">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                  <UserIcon className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 text-left">{userInfo.username}</h2>
                  <p className="text-sm text-gray-500">{userInfo.email}</p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 grid grid-cols-1 sm:grid-cols-4 gap-4 items-center">
              <div className="text-center">
                <p className="text-sm text-gray-500">Bookings</p>
                <p className="text-2xl font-semibold">0</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">Gender</p>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm text-center text-lg font-semibold"
                  value={gender}
                  onChange={e => setGender(e.target.value)}
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                  <option>Prefer not to say</option>
                </select>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">Phone Number</p>
                <p className="text-2xl font-semibold">123-456-7890</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">Address</p>
                <p className="text-2xl font-semibold">Mumbai</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">Marital Status</p>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm text-center text-lg font-semibold"
                  value={maritalStatus}
                  onChange={e => setMaritalStatus(e.target.value)}
                >
                  <option>Single</option>
                  <option>Married</option>
                  <option>Divorced</option>
                  <option>Widowed</option>
                </select>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">State</p>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm text-center text-lg font-semibold"
                  value={state}
                  onChange={e => setState(e.target.value)}
                >
                  <option>Maharashtra</option>
                  <option>Delhi</option>
                  <option>Karnataka</option>
                  <option>Tamil Nadu</option>
                  <option>West Bengal</option>
                  <option>Uttar Pradesh</option>
                  <option>Gujarat</option>
                  <option>Rajasthan</option>
                  <option>Punjab</option>
                  <option>Other</option>
                </select>
              </div>
            </div>
          </div>

          {/* Bookings Tabs */}
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="border-b border-gray-200 flex items-center justify-between px-4">
              <nav className="flex -mb-px">
                <button
                  onClick={() => setActiveTab('current')}
                  className={`py-4 px-6 text-center border-b-2 font-medium text-sm ${activeTab === 'current' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                >
                  Current Bookings
                </button>
                <button
                  onClick={() => setActiveTab('past')}
                  className={`py-4 px-6 text-center border-b-2 font-medium text-sm ${activeTab === 'past' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                >
                  Booking History
                </button>
              </nav>
              <button
                className="ml-4 px-6 py-2 bg-blue-600 text-white rounded-lg font-semibold shadow hover:bg-blue-700 transition"
                onClick={() => navigate('/checkin')}
              >
                Check-in
              </button>
            </div>

            {/* Bookings List */}
            <div className="p-6">
              {bookings[activeTab].length > 0 ? (
                <div className="space-y-6">
                  {bookings[activeTab].map((booking) => (
                    <div key={booking.id} className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                        <div>
                          <span className="text-sm font-medium text-gray-900">Booking #{booking.id}</span>
                          <span className={`ml-2 px-2 py-1 text-xs rounded-full ${
                            booking.status === 'Confirmed' ? 'bg-green-100 text-green-800' :
                            booking.status === 'Completed' ? 'bg-blue-100 text-blue-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {booking.status}
                          </span>
                        </div>
                        <span className="text-sm font-semibold text-gray-900">{booking.price}</span>
                      </div>
                      <div className="p-4">
                        <div className="flex items-start">
                          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-50 flex items-center justify-center">
                            <TicketIcon className="h-5 w-5 text-blue-600" />
                          </div>
                          <div className="ml-4">
                            <h3 className="text-lg font-medium text-gray-900">{booking.airline} - {booking.flight}</h3>
                            <p className="text-sm text-gray-500">{booking.route}</p>
                          </div>
                        </div>
                        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="flex items-center">
                            <CalendarIcon className="flex-shrink-0 h-5 w-5 text-gray-400" />
                            <span className="ml-2 text-sm text-gray-500">{booking.date}</span>
                          </div>
                          <div className="flex items-center">
                            <ClockIcon className="flex-shrink-0 h-5 w-5 text-gray-400" />
                            <span className="ml-2 text-sm text-gray-500">{booking.time}</span>
                          </div>
                          <div className="flex items-center">
                            <UserIcon className="flex-shrink-0 h-5 w-5 text-gray-400" />
                            <span className="ml-2 text-sm text-gray-500">Seats: {booking.seats.join(', ')}</span>
                          </div>
                        </div>
                        {activeTab === 'current' && booking.status === 'Confirmed' && (
                          <div className="mt-4 flex space-x-3">
                            <button
                              onClick={() => navigate(`/manage-booking/${booking.id}`)}
                              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                            >
                              Manage Booking
                            </button>
                            <button
                              onClick={() => console.log('Cancel booking', booking.id)}
                              className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                            >
                              Cancel Flight
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
                    <TicketIcon className="h-6 w-6 text-gray-400" />
                  </div>
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No {activeTab === 'current' ? 'current' : 'past'} bookings</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    {activeTab === 'current' 
                      ? "No upcoming trips on your calendar—why not plan your next adventure?"
                      : "Your past bookings will appear here."}
                  </p>
                  <div className="mt-6">
                    <Link
                      to="/"
                      className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Grab the Next Flight
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ProfilePage;