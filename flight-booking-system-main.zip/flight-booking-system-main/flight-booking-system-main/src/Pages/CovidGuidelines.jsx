import React from "react";
import { useNavigate } from "react-router-dom";

const CovidGuidelines = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-white">
      <div className="bg-white rounded-2xl shadow-xl p-10 w-full max-w-2xl">
        <h2 className="text-3xl font-bold text-blue-900 mb-6 text-center">
          COVID-19 Travel Guidelines
        </h2>
        <ul className="list-disc pl-6 text-gray-700 space-y-3 mb-8">
          <li>
            <span className="font-semibold">Mask Required:</span> All passengers
            must wear a mask at all times in the airport and during the flight.
          </li>
          <li>
            <span className="font-semibold">Thermal Screening:</span> Temperature
            checks will be conducted at entry points.
          </li>
          <li>
            <span className="font-semibold">Sanitization:</span> Please use hand
            sanitizers provided at various points in the airport.
          </li>
          <li>
            <span className="font-semibold">Social Distancing:</span> Maintain at
            least 6 feet distance from others in queues and waiting areas.
          </li>
          <li>
            <span className="font-semibold">Health Declaration:</span> Fill out
            the health declaration form before boarding.
          </li>
          <li>
            <span className="font-semibold">Contactless Boarding:</span> Use
            digital boarding passes and minimize contact with surfaces.
          </li>
          <li>
            <span className="font-semibold">Quarantine Rules:</span> Follow the
            quarantine and testing rules as per your destination state/country.
          </li>
          <li>
            <span className="font-semibold">Vaccination:</span> Carry your
            vaccination certificate if required by your destination.
          </li>
        </ul>
        <button
          className="w-full bg-blue-600 text-white font-semibold py-2 rounded-lg hover:bg-blue-700 transition"
          onClick={() => navigate(-1)}
        >
          Back
        </button>
      </div>
    </div>
  );
};

export default CovidGuidelines;