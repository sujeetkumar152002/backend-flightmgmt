import React from "react";
import { useNavigate } from "react-router-dom";

const TermsAndConditions = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-white p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-3xl overflow-y-auto max-h-[90vh]">
        <h2 className="text-3xl font-bold text-blue-900 mb-6 text-center">Terms and Conditions</h2>
        <div className="text-gray-700 space-y-4 text-sm" style={{whiteSpace: 'pre-line'}}>
{`
JetSetGo Aviation Limited’s (“JetSetGo”) website, www.gojetsetgo.in is offered to the Customers on the express condition of acceptance of these terms and conditions. The terms and conditions shall be deemed to constitute a legally binding contract between JetSetGo and the Customer. If these terms and conditions are not acceptable to the Customer, the Customer is requested to exit JetSetGo website (term as defined below).

JetSetGo authorizes the Customer to view the content available on its website www.gojetsetgo.in. The Customer is not permitted to copy, replicate, modify, derivative, display, perform, create derivative works from, transfer or sell any information obtained from JetSetGo website, whether in print, visual or electronic form, for any purpose whatsoever, without the prior written permission, at the sole discretion of JetSetGo. Customers may not use JetSetGo’s website, www.gojetsetgo.in or any micro site comprised in www.gojetsetgo.in, or any other JetSetGo owned website accessible through the use of www.gojetsetgo.in (all of which are collectively referred as ‘JetSetGo website’), for any purpose that is unlawful or that is otherwise prohibited by these conditions of use.

Customers must not:

resell the services provided in the JetSetGo website,
use the JetSetGo website to make any speculative, false or fraudulent Booking,
use the JetSetGo website so as to interfere with others’ use of the JetSetGo website.
JetSetGo does not warrant or represent that use of the JetSetGo website or its online booking facility or any third party payment systems used for making payments to JetSetGo will be uninterrupted or error-free or that any information, data, content, software or other material accessible through the JetSetGo website will be free of bugs, viruses, worms, Trojan horses or other harmful components.

Customers represent that, unless otherwise specifically permitted by JetSetGo, the JetSetGo website and all the products and services offered by JetSetGo, including without limitation, are meant for personal and non-commercial use only, and cannot be redistributed by them to any person not authorised to receive the same.

Customers represent that they are of sufficient legal age to use this service, and they possess the legal right and ability to create binding obligations for any liability that they may incur as a result of the use of this service.

Customers understand that they are financially responsible for all uses of this service by them and those using their login information.

Customers will supervise all usage of the booking facility under their name or account.

Customers warrant that all information supplied by them and members of their household in using the booking facility are true and accurate.

JetSetGo and its licensors retain all rights (including copyright and patent rights) with respect to all softwares and underlying information and material available through the JetSetGo website.

Customers must not download or otherwise export or re-export any software or underlying information or material available through the JetSetGo website except with the written permission of JetSetGo and in full compliance with all Indian and other applicable laws and regulations, provided, however that any downloading that occurs in the normal course of using the JetSetGo website in accordance with the published written instructions of JetSetGo shall not be prohibited.

JetSetGo website may contain hyperlinks to websites operated by parties other than JetSetGo. Such hyperlinks are provided for your reference only. JetSetGo does not control such websites and is not responsible for their content(s). JetSetGo’s inclusion of hyperlinks to such websites does not imply any endorsement of the material on such websites or any association with their operators.

JetSetGo, its parent company and/or its affiliates may also present advertisements or promotional materials on or through JetSetGo website. Customer’s participation in any promotional event is subject to the terms and conditions associated with that event. Customer’s dealings with, or participation in promotions of, any third-party advertisers on or through the JetSetGo website are solely between the Customer and such third-party. Customer agrees that JetSetGo, its parent company and/or its affiliates shall not be responsible or liable for any loss or damage of any sort incurred as the result of any such dealings or as the result of the presence of such third parties reference on the JetSetGo website.

Without limiting any of the disclaimers of warranty set forth in these terms and conditions, JetSetGo does not provide or make any representation as to the quality or nature of any of the third party information, products or services provided through the JetSetGo website, or any other representation, warranty or guaranty. Furthermore, JetSetGo in particular disclaims any responsibility, if such third party websites:

infringe any third party’s intellectual property rights,
provide any information which is inaccurate, incomplete or misleading,
are not merchantable or fit for a particular purpose,
do not undertake adequate security measures,
contain viruses or other items of destructive nature, or
provide any libelous or defamatory contents or information.
The information contained and/or provided in this website is meant solely for information purposes and should not be relied upon for any other use whatsoever.

Customer’s use of JetSetGo website constitutes Customer’s agreement to be bound, without any modifications or reservations whatsoever, by these terms and conditions, which may be updated or modified from time to time without notice to the Customer. Any change(s) shall become part of these terms and conditions and shall apply immediately. By continuing to use the JetSetGo website after such modifications, Customer indicates acceptance of those modifications. Customer may also be required to re-accept the substantially revised terms and conditions to continue to use the JetSetGo website.

These terms and conditions are governed by the laws of India. Customer hereby consents to the exclusive jurisdiction and venue of courts in New Delhi in all disputes arising out of or relating to the use of the JetSetGo website. Use of the JetSetGo website is unauthorized in any jurisdiction that does not give effect to all provisions of these terms and conditions, including without limitation this paragraph.

Any rights or permissions not expressly granted herein are reserved.

For any requests pertaining to customer data accessibility including profile deletion, you can raise a request to customer.relations@gojetsetgo.in.

Upon exercising such an option, your personal information shall not, in the future, be available for bookings by you. However, please note that JetSetGo shall be required to retain your personal/booking data/travel records and history, for its legitimate use or for such period as per law. Also, requests such as opting out of, or unsubscribing from receiving promotional communication is to be raised through the same process i.e., by sending an email to customer.experience@gojetsetgo.in.
`}
        </div>
        <button
          className="w-full bg-blue-600 text-white font-semibold py-2 rounded-lg hover:bg-blue-700 transition mt-8"
          onClick={() => navigate(-1)}
        >
          Back
        </button>
      </div>
    </div>
  );
};

export default TermsAndConditions;
