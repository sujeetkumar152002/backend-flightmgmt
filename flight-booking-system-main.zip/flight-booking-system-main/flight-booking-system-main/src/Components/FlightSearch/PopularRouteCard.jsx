const OffersAndDealsCard = ({ 
  destination, 
  image, 
  discount, 
  validity 
}) => {
  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow bg-white">
      <div className="h-40 relative">
        <img
          src={image}
          alt={destination}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900">{destination}</h3>
        <div className="text-red-600 font-bold text-md mt-1">{discount} OFF</div>
        <div className="text-sm text-gray-500 mt-1">Valid till {validity}</div>
        <button className="mt-4 w-full bg-blue-600 text-white text-sm py-2 rounded hover:bg-blue-700 transition">
          Grab Deal
        </button>
      </div>
    </div>
  );
};

export default OffersAndDealsCard;
