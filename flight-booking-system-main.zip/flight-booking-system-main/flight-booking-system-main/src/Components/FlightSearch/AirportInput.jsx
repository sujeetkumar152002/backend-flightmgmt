import { FiSearch } from 'react-icons/fi';

const AirportInput = ({ 
  id, 
  label, 
  value, 
  onChange, 
  placeholder, 
  suggestions, 
  onSuggestionClick,
  isActive 
}) => {
  return (
    <div className="relative">
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <div className="relative">
        <input
          type="text"
          id={id}
          name={id}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          autoComplete="off"
        />
        <FiSearch className="absolute left-3 top-3.5 text-gray-400" />
        {isActive && suggestions.length > 0 && (
          <ul className="absolute z-10 mt-1 w-full bg-white shadow-lg rounded-md py-1 max-h-60 overflow-auto">
            {suggestions.map((airport, index) => (
              <li
                key={index}
                className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                onClick={() => onSuggestionClick(airport)}
              >
                <div className="font-medium">{airport.city} ({airport.code})</div>
                <div className="text-sm text-gray-500">{airport.name}</div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default AirportInput;