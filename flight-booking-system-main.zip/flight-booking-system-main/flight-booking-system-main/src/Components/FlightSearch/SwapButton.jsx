import { FaArrowRightArrowLeft } from "react-icons/fa6";

const SwapButton = ({ onClick }) => {
  return (
    <div className="flex items-end justify-center">
      <button
        type="button"
        onClick={onClick}
        className="p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors"
        aria-label="Swap destinations"
      >
        <FaArrowRightArrowLeft className="text-gray-600 rotate-90 sm:rotate-0" />
      </button>
    </div>
  );
};

export default SwapButton;