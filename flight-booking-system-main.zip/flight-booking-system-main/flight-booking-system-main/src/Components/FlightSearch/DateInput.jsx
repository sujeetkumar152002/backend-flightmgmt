import { FiCalendar } from 'react-icons/fi';

const DateInput = ({ id, label, value, onChange }) => {
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <div className="relative">
        <input
          type="date"
          id={id}
          name={id}
          value={value}
          onChange={onChange}
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
        <FiCalendar className="absolute left-3 top-3.5 text-gray-400" />
      </div>
    </div>
  );
};

export default DateInput;